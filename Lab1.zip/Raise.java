package Labb1;


public class Raise {
	//denna count används i raiseone
	static int count=0;
	//denna count används i rasehalf. 
	static int counT=0;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i=1; i<15; i++) {
			count=0;
			counT=0;
			System.out.println("Med N_one blir det; "+ N_one(i));
			System.out.println("Med N_half blir det; "+N_half(i));
			
		
		System.out.println("Resultaten  av recRaiseHalf funktionen blir det: " +recRaiseHalf(1.5, i));		
		System.out.print("Den totala antal anrop for "
				+ " recRaiseHalf funktionen blir det:  "  +count + "\n");
		System.out.println("Resultaten av recRaiseOne fuktionen det: " +recRaiseOne(1.5, i));
		System.out.print("Den totala antal anrop for "
				
				+ " recRaiseOne funktionen blir det : "  +counT);
		}
		
		


	}
	 //upgift 7
	public static double recRaiseOne(double x, int k) {
		counT+=1;
		if (k==0) {
		return 1.0;
		} 
		
		else {
				
			return x * recRaiseOne (x, k-1);	
	
		 
		}

	}
	
	//uppgift 8
	public static double recRaiseHalf(double x, int k) {
		
		count +=1;
		int s=k/2;
		//x^k =y
		double y;
		if (k==0) {
			return 1;
		}
		else if ( k%2==0) {
			y= recRaiseHalf(x,s);
			
			
			y=y*y;
		
		}
		else {
			y= recRaiseHalf(x,s);			
			
			y=(x*y*y);
			
		}
		
		return y;
	}

	//uppgift 10
	public static int N_one(int k) {
		
		recRaiseOne(1.5, k);
		return counT;
		
	}
	//uppgift 10
	public static int N_half(int k) {
		recRaiseHalf(1.5, k);
		return count;
		
	}
		}

//uppgift 10.1
/* k vardet paverkar mest for att den ska multiplicera forst 
 sedan ska den upphoja x vardet med det. t.ex om vi tar 1000 ^5
 jamfor med 5 ^1000. sa klart att 5^1000 tar langre tid jamfor  med 1000^5.

*/