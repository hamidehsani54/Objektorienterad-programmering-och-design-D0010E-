package Labb1;

public class LifeLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a0 = Integer.parseInt(args[0]);
		//switch for att valja olika alternativ. 
		int val=6;
		switch (val) {
		case 1:
			task1(a0);
			break;
		case 2:
			task2(a0);
			break;
		case 3:
			task3();
			break;
		case 4:
			task4();
			break;
		case 6:
			task6(a0);
			break;
		default:
			System.out.println("felaktigt val");
		

			
		}


	}
	//method for task1
	public static void task1(int a0) {
		System.out.println("resultat av f1 " + f1(a0));
		
	}
	//method for task2
	public static void task2(int a0) {
		//den som skrivs ut pa skarem genom att kalla pa mina funtioner i uppgift 2. 
		System.out.println("resultat av f1 " + f1(a0));
		System.out.println("resultat av f2 " + f2(a0));
		System.out.println("resultat av f4 " + f4(a0));
		System.out.println("resultat av f8 " + f8(a0));
		System.out.println("resultat av f16 " + f16(a0));
		System.out.println("resultat av f32 " + f32(a0));
		
	}
	//method for task3
	public static void task3() {
		//uppgift 3
		System.out.println("Iteratef " + iterateF(3,2));
		System.out.println("Iteratef " + iterateF(42,3));
		System.out.println("Iteratef " + iterateF(1,3));
	}
	
	////method for task4
	public static void task4() {
		//loop for att variera olika varde pa k.
		for (int i=1; i<16; i++) {
			
			System.out.println(intsToString(i, iterLifeLength( i)));
		}
		
	}
	//method for task6
	public static void task6(int a0) {
	for (int i=1; i<16; i++) {
			
		System.out.println((recLifeLength(i) + " " +iterLifeLength(i)));
		}
	}
	
	
	//uppgift 1
	public static int f1(int a0) {
		//om a0 ar 0
		if (a0==1) {
		return 1;}
		else if (a0%2 ==0) {
			a0= a0/2;
		}
		// annrs
		else {			 
			a0 =(3*a0 + 1);
			}
		return a0;
	}
	
	
	// uppgift 2
	static int f2(int a0) {
		return (f1(f1(a0)));
		}
	static int f4(int a0) {
		return f2(f2((a0)));
		}
	static int f8(int a0) {
		return (f4(f4(a0)));
		}
	
	static int f16(int a0) {
		return f8(f8(((a0))));
		}
	static int f32(int a0) {
		return f16(f16(a0));
		}
	
	//uppgift 3
	public static int iterateF(int a0, int n ) {
		//denna loopen kollar hur många n varav ska den k�ra. 
		for (int count=0;  count<n; count++) {
			//har a0 far ett nytt varde
			a0=f1(a0);	
		}
		return a0;

	}
	
	//uppgift 4
	public static int iterLifeLength(int a0) {
		int p=0;
		for(int i =0; i>=0; i++) {
			if (a0 !=1) {
				a0=f1(a0);
				}
			else {
				p= i;
				break;
				
			}
		}
		return p;
	
	}
	
	static String intsToString(int X, int Y) {
		
		return ("The life length of " + X + " is " + Y + ".");
		
	}
	
	//uppgift 6
	static int recLifeLength(int a0) {
	
			if(a0 ==1) {
				return 0;}
			else {
				return recLifeLength(f1(a0))+ 1;

			} 
		
		
		
		
	}

}
	

//uppgift 7, den terminerar inte. 


//Hamidullah Qurban

	

