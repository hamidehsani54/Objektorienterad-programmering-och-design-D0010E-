package mainlab;

import lab4.client.GomokuClient;
import lab4.data.GomokuGameState;
import lab4.gui.GomokuGUI;

public class Gomokumain {

	public static void main(String[] argv) {
		/**
		 * Make sure that the port number is correct and is a higher number than 4000,
		 * otherwise a number will be set.
		 */
		int clientPort1;
		int clientPort2;
		if (Integer.parseInt(argv[0]) < 4000) {
			clientPort1 = 6005;
		} else {
			clientPort1 = Integer.parseInt(argv[0]);
		}
		if (Integer.parseInt(argv[1]) < 4000) {
			clientPort2 = 8005;
		} else {
			clientPort2 = Integer.parseInt(argv[1]);
		}

		/*
		 * Connect and create the visual objects for the game
		 */
		GomokuClient client1 = new GomokuClient(clientPort1);
		GomokuClient client2 = new GomokuClient(clientPort2);

		GomokuGameState player1 = new GomokuGameState(client1);
		GomokuGameState player2 = new GomokuGameState(client2);
		
		GomokuGUI player1GUI = new GomokuGUI(player1, client1);
		GomokuGUI player2GUI = new GomokuGUI(player2, client2);
	}
}



