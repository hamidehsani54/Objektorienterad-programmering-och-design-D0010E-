package lab4.gui;

import java.util.Observable;
import java.util.Observer;
import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.event.*;
import lab4.client.GomokuClient;
import lab4.data.GameGrid;
import lab4.data.GomokuGameState;
import lab4.gui.ConnectionWindow;

/**
 * @author Marcus and Hamid
 *
 *
 *
 *         The GUI class
 */
public class GomokuGUI implements Observer {

	private GomokuClient client;
	private GomokuGameState gamestate;
	private GamePanel gameGridPanel;
	private JLabel messageLabel;
	private JButton connectButton;
	private JButton newGameButton;
	private JButton disconnectButton;
	private ConnectionWindow connectionWindow;
	private MouseAdapter mouseList;
	int size;
	/**
	 * The constructor
	 * 
	 * @param g The game state that the GUI will visualize
	 * @param c The client that is responsible for the communication
	 */
	public GomokuGUI(GomokuGameState g, GomokuClient c) {
		this.client = c;
		this.gamestate = g;
		client.addObserver(this);
		gamestate.addObserver(this);
		JFrame frame = new JFrame();
		messageLabel = new JLabel();
		messageLabel.setText(gamestate.getMessageString());
		gameGridPanel = new GamePanel(gamestate.getGameGrid());
		gameGridPanel.setVisible(true);
		

	
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocation(200, 200);
		//frame.setSize(gamestate.DEFAULT_SIZE * gameGridPanel.UNIT_SIZE + 10, gamestate.DEFAULT_SIZE * gameGridPanel.UNIT_SIZE + 90);
		frame.setTitle("Gomoku");
		frame.setVisible(true);
		
		

		// add a mouse adapter for the game grid panel
		MouseAdapter mouseList = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) { 
				gamestate.move((gameGridPanel.getGridPosition(e.getX(), e.getY())[0]),
						((gameGridPanel.getGridPosition(e.getX(), e.getY()))[1]));
			}

		};

		// add the connect button to the frame
		connectButton = new JButton("Connect");
		connectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String input = arg0.getActionCommand();
				connectionWindow = new ConnectionWindow(client);
				messageLabel.setText(" Waiting for connection window......");
			}
		});

		// add the new game button to the frame
		newGameButton = new JButton("New Game");
		newGameButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String input = e.getActionCommand();
				gamestate.newGame();
				messageLabel.setText(gamestate.getMessageString());
			}
		});

		// add the disconnect button the the frame
		disconnectButton = new JButton("Disconnect");
		disconnectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				String input = a.getActionCommand();
				gamestate.disconnect();
				messageLabel.setText("You have disconnected from the game");
			}
		});

		if (gamestate.currentState == gamestate.NOT_STARTED) {
			newGameButton.setEnabled(false);
			disconnectButton.setEnabled(false);
			messageLabel.setText(gamestate.getMessageString());
		}

		Box insertButtons = Box.createHorizontalBox();
		insertButtons.add(connectButton);
		insertButtons.add(newGameButton);
		insertButtons.add(disconnectButton);
		Box allContent = Box.createVerticalBox();
		Box gridPanel = Box.createHorizontalBox();
		Box insertlabel = Box.createHorizontalBox();
		gridPanel.add(gameGridPanel);
		insertlabel.add(messageLabel);
		allContent.add(gridPanel);
		allContent.add(insertButtons);
		allContent.add(insertlabel);
		frame.add(allContent);
		frame.pack();
		
		
		gameGridPanel.addMouseListener(mouseList);
	}

	public void update(Observable arg0, Object arg1) {

		// Update the buttons if the connection status has changed
		if (arg0 == client) {
			if (client.getConnectionStatus() == GomokuClient.UNCONNECTED) {
				connectButton.setEnabled(true);
				newGameButton.setEnabled(false);
				disconnectButton.setEnabled(false);
			} else {
				connectButton.setEnabled(false);
				newGameButton.setEnabled(true);
				disconnectButton.setEnabled(true);
			}
		}

		// Update the status text if the gamestate has changed
		if (arg0 == gamestate) {
			messageLabel.setText(gamestate.getMessageString());
		}

	}

}