package main;

import market.CloseEvent;
import market.EntryEvent;
import market.MarketState;
import market.MarketView;
import market.OpenEvent;
import market.StopEvent;
import simulator.EventQueue;
import simulator.Simulator;
import java.util.Random;

/**
 * @author Marcus Paulsson, Hamid Ehsani
 *
 *
 *
 *	Represents an optimization of the market depending on different parameters
 */
public class Optimize {

	
	/*
	 *  different example runs to test in order to test the class
	 */
	// Ex 1:
//	public static final int M = 5;
//	public static final double L = 1;
//
//	public static final double LOW_COLLECTION_TIME = 0.5d;
//	public static final double HIGH_COLLECTION_TIME = 1d;
//
//	public static final double LOW_PAYMENT_TIME = 2d;
//	public static final double HIGH_PAYMENT_TIME = 3d;
//
//	public static final int SEED = 1234;
//	public static final double END_TIME = 10.0d;
//	public static final double STOP_TIME = 999.0d;

	// Ex 2:
			  public static final int M = 7;
			  public static final double L = 2;
		
			  public static final double LOW_COLLECTION_TIME = 0.5d;
			  public static final double HIGH_COLLECTION_TIME = 1d;
		
			  public static final double LOW_PAYMENT_TIME = 2d;
			  public static final double HIGH_PAYMENT_TIME = 3d;
		
			  public static final int SEED = 1234;
			  public static final double END_TIME = 10.0d;
			  public static final double STOP_TIME = 999.0d;

	// Ex 3: (som sim2)
	// public static final int M = 7;
	// public static final double L = 3;
	//
	// public static final double LOW_COLLECTION_TIME = 0.6d;
	// public static final double HIGH_COLLECTION_TIME = 0.9d;
	//
	// public static final double LOW_PAYMENT_TIME = 0.35d;
	// public static final double HIGH_PAYMENT_TIME = 0.6d;
	//
	// public static final int SEED = 13;
	// public static final double END_TIME = 8.0d;
	// public static final double STOP_TIME = 999.0d;

	// Ex 4
//		    public static final int M = 100;
//		    public static final double L = 50;
//	
//		    public static final double LOW_COLLECTION_TIME = 0.45d;
//		    public static final double HIGH_COLLECTION_TIME = 0.65d;
//	
//		    public static final double LOW_PAYMENT_TIME = 0.2d;
//		    public static final double HIGH_PAYMENT_TIME = 0.3d;
//	
//		    public static final int SEED = 42;
//		    public static final double END_TIME = 20.0d;
//		    public static final double STOP_TIME = 999.0d;

	// Ex 5

//		    public static final int M = 1400;
//		    public static final double L = 100;
//	
//		    public static final double LOW_COLLECTION_TIME = 0.45d;
//		    public static final double HIGH_COLLECTION_TIME = 0.65d;
//	
//		    public static final double LOW_PAYMENT_TIME = 0.2d;
//		    public static final double HIGH_PAYMENT_TIME = 0.3d;
//	
//		    public static final int SEED = 42;
//		    public static final double END_TIME = 20.0d;
//		    public static final double STOP_TIME = 999.0d;

	// Ex 6

//		    public static final int M = 1400;
//		    public static final double L = 700;
//	
//		    public static final double LOW_COLLECTION_TIME = 0.45d;
//		    public static final double HIGH_COLLECTION_TIME = 0.65d;
//	
//		    public static final double LOW_PAYMENT_TIME = 0.2d;
//		    public static final double HIGH_PAYMENT_TIME = 0.3d;
//	
//		    public static final int SEED = 42;
//		    public static final double END_TIME = 20.0d;
//		    public static final double STOP_TIME = 999.0d;

	// Ex 7
//		    public static final int M = 1400;
//		    public static final double L = 2000;
//	
//		    public static final double LOW_COLLECTION_TIME = 0.45d;
//		    public static final double HIGH_COLLECTION_TIME = 0.65d;
//	
//		    public static final double LOW_PAYMENT_TIME = 0.2d;
//		    public static final double HIGH_PAYMENT_TIME = 0.3d;
//	
//		    public static final int SEED = 42;
//		    public static final double END_TIME = 20.0d;
//		    public static final double STOP_TIME = 999.0d;

	private int checkouts = 1;
	private int checkoutsLimit = Integer.MAX_VALUE;
	private MarketState marketState;
	private MarketView marketView;

	/* 
	 *  The Main Class
	 */
	public static void main(String[] args) {
		Optimize optimize = new Optimize();

		System.out.println("Max som ryms, M..........: " + M);
		System.out.println("Ankomsthastighet, lambda.: " + L);
		System.out.println("Plocktider, [P_min..PMax]: [" + LOW_COLLECTION_TIME + ".." + HIGH_COLLECTION_TIME + "]");
		System.out.println("Betaltider, [K_min..Kmax]: [" + LOW_PAYMENT_TIME + ".." + HIGH_PAYMENT_TIME + "]");
		System.out.println("Frö, f...................: " + SEED + "\n");
		System.out.println("Stängning sker tiden " + END_TIME + " och stophändelsen sker tiden " + STOP_TIME + ". \n");
		optimize.optimizeCheckouts(SEED);
	}
	/**
	 *	Runs the marketsimulator without printing
	 * 
	 * @param seed
	 * @param checkouts
	 * @return The specific runState
	 */
	public MarketState runSimulator(int seed, int checkouts) {
		EventQueue eventQueue1 = new EventQueue();

		MarketState marketState1 = new MarketState(0, true, eventQueue1, M, checkouts, END_TIME);
		marketState1.randomGenerator(seed, L, LOW_COLLECTION_TIME, HIGH_COLLECTION_TIME, LOW_PAYMENT_TIME,
				HIGH_PAYMENT_TIME);
		double time1 = marketState1.getRandomCostumerRate();

		eventQueue1.sortEventSequence(new OpenEvent(marketState1, 0));
		eventQueue1.sortEventSequence(new EntryEvent(time1, marketState1));
		eventQueue1.sortEventSequence(new CloseEvent(END_TIME, marketState1));
		eventQueue1.sortEventSequence(new StopEvent(STOP_TIME, marketState1));
		Simulator.run(eventQueue1, marketState1);

		return marketState1;
	}

	/**
	 * Runs the simulator in order to find the best amount of checkouts
	 * 
	 * @param seed
	 * @return The most efficient amount of checkouts
	 */
	public int optimizeCheckouts(int seed) {
		
		MarketState best = runSimulator(seed, checkouts);

		for (int i = 1; i <= best.getmaxCustomers(); i++) {
			MarketState temp = runSimulator(seed, checkouts);

			if (temp.getMissedCustomer() < best.getMissedCustomer()) {
				best = temp;
			}
			checkouts++;
		}
		checkouts = 1;
		marketState = best;
		
		System.out.print("Minsta antal kassor som ger minimalt antal missade ("+best.getMissedCustomer()+"):"+best.getNumCheckouts()+"\n");
		return best.getNumCheckouts();
		
	}
	/**
	 * Runs the simulator in order to find the best amount of checkouts with different seeds
	 * 
	 * @param seed
	 * @return The most efficient amount of checkouts with a specific seed
	 */
	public void optimizeWithSeed(int Seed) {
		int leastCheckouts = 1;
		int i = 0;
		Random rand = new Random(SEED);
		while(i < 100) {
			int checkoutCount = optimizeCheckouts(rand.nextInt());
			if (checkoutCount > leastCheckouts) {
				leastCheckouts = checkoutCount;
				i = 0;
			}
			else {
				i++;
			}
		}
		System.out.print(leastCheckouts);
	}
	

}