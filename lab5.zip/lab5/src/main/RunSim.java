package main;

import market.*;
import simulator.*;

/**
*
**
 * @author Marcus Paulsson, Hamid Ehsani
 *
*The Main Class for the simulator
*
*/
public class RunSim {
	
public static void main(String[] args) {
		
	
	/**
	 * SimEx 1:
	 * 
	 * Print the first asked simulation
	 */
		System.out.println("Simulering 1:\n");
		EventQueue eventQueue1 = new EventQueue();
		
		MarketState marketState1 = new MarketState(0, true, eventQueue1, 5, 2, 10); // SuperMarket(double time, boolean flag, EventQueue eventQueue, int maxCustomers, int checkouts, double timeopen)
		marketState1.randomGenerator(1234, 1.0, 0.5, 1.0, 2.0, 3.0);
	
		MarketView marketView1 = new MarketView(marketState1);
		
		eventQueue1.sortEventSequence(new OpenEvent(marketState1, 0));
		double time1 = marketState1.getRandomCostumerRate();
		eventQueue1.sortEventSequence(new EntryEvent(time1, marketState1));
		eventQueue1.sortEventSequence(new CloseEvent(10, marketState1)); // parameter for when the close
		eventQueue1.sortEventSequence(new StopEvent(999, marketState1));
		
		/**
		 * 	What you see in the Colsole
		 */
		marketView1.printParameters();
		Simulator.run(eventQueue1, marketState1);
		marketView1.printResults(); 
		
		
		/**
		 * SimEx 2:
		 * 
		 * Print the second asked simulation
		 */
		System.out.println("\nSimulering 2:\n");
		EventQueue eventQueue2 = new EventQueue();
		
		MarketState marketState2 = new MarketState(0, true, eventQueue2, 7, 2, 8); // SuperMarket(double time, boolean flag, EventQueue eventQueue, int maxCustomers, int checkouts, double timeopen)
		marketState2.randomGenerator(13, 3.0, 0.6, 0.9, 0.35, 0.6);
		MarketView marketView2 = new MarketView(marketState2);
		double time2 = marketState2.getRandomCostumerRate();
		
		eventQueue2.sortEventSequence(new OpenEvent(marketState2, 0));
		eventQueue2.sortEventSequence(new EntryEvent(time2, marketState2));
		eventQueue2.sortEventSequence(new CloseEvent(8, marketState2)); // parameter for when the close
		eventQueue2.sortEventSequence(new StopEvent(999, marketState2));

		/**
		 * 	What you see in the Colsole
		 */
		marketView2.printParameters();
		Simulator.run(eventQueue2, marketState2);
		marketView2.printResults(); 
		
	}
}