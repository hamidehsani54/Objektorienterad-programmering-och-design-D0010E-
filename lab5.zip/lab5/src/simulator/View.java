package simulator;

import java.util.Observable;
import java.util.Observer;

/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 *This Class represent the view that are extended to the specific simulator
 */
public class View implements Observer {
	
	public void update(Observable arg0, Object arg1) {
		
	}

}