package simulator;

/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 *	This Class represents the state of the simulation
 */
public abstract class Event {
	
	private State state;
	private double time;
	
	/**
	 * Constructor
	 * 
	 * @ set time and state variables to timeArg and stateArg
	 */
	public Event(double timeArg, State stateArg) { 
		this.time = timeArg;
		this.state = stateArg;
	}
	/*
	 * return time
	 */
	public double getTime() {
		return time;
	}

	/*
	 * return the state
	 */
	public State getState() {
		return state;
	}
	
	/*
	 * run Event
	 */
	public abstract void runEvent();

}