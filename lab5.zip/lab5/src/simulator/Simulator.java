package simulator;

import market.*;
/**
 * @author hamidullah.qurban ,Marcus Paulsson
 *
 *
 *This Class represent the simulator and run the events
 *
 */
public class Simulator {


	 // @ runs for next index until it takes stop.
	 
	public static void run(EventQueue eventQueue, MarketState marketState) {
		while (marketState.getFlag()) {
			if (!eventQueue.tryNextEvent()) {
				break;
			}
		}
	}

}