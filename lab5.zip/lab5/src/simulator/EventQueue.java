package simulator;

import java.util.ArrayList;
/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 *
 *	This Class keeps track and sort the events by its time and state
 */

public class EventQueue {

	public ArrayList <Event> eventQueue = new ArrayList<Event>();

	/*
	 *  tre olika senarion,... 
	 *  1: Placera efter näst högst tid, 
	 *  2: Placera framför på första position, 
	 *  3: inget annat event, placeras på första postion.
	 */
	public void sortEventSequence(Event eventArg){
				boolean firstPosition = true;
				if (eventQueue.size() != 0) {
					for(int i = 0; i < eventQueue.size();i++) {
						if(eventArg.getTime() < eventQueue.get(i).getTime()) {
							eventQueue.add(i,eventArg); // 1:
							firstPosition = false;
							break;
						}
					}
					if(firstPosition == true) {
						eventQueue.add(eventArg);	 // 2:
					}
					
				}else {
					eventQueue.add(eventArg); // 3:
				}
	}

	/**
	 * @return false and true depends to condition. 
	 */
	public boolean tryNextEvent(){
		if (eventQueue.size() == 0) {
			return false;
		}
		else {
			Event eventHolder = eventQueue.get(0);
			eventQueue.remove(0);
			eventHolder.runEvent();
			return true;
		}
	}
	
	/**
	 * @return the first index of eventQueue if it has 
	 */
	public Event getFirstEvent() {
		if(eventQueue.size()==0) {
			System.out.print("Error");
			return null;
		}
		else {
		return eventQueue.get(0);
		}
	}

	public void sortEventSequence(double timeArg, Event eventArg) { 
	
	}
	
	/**
	 * @return eventQueue
	 */
	public ArrayList getEventQueue () {
		return eventQueue;
	}
	
}