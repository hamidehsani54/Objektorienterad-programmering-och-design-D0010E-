package simulator;

import java.util.Observable;


/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 */
public class State extends Observable{
	
	private boolean flag = false; 
	private double time;
	private Event event; 
	private Class type; 
	private EventQueue eventQueue; 

	/*
	 * constructor with flag, time and eventQueue variables. 
	 */
	public State(double time, boolean flag, EventQueue eventQueue){
		this.flag=flag;
		this.time=time;
		this.eventQueue = eventQueue;
	}
	
	//@ flag gets a value (flagArg).
	 
	public void setFlag(boolean flagArg){
		flag = flagArg;
	}
	
	// @return flag
	public boolean getFlag(){
		return flag;
	}
	
	// @time gets a value (timeArg)
	public void setTime(double timeArg){
		time = timeArg;
	}
	
	//@return time
	public double getTime(){
		return time;
	}
	
	//@return event
	public Event getEvent(){
		return event;
	}

	  // @ event gets a value which is eventArg
	public void nextEvent(Event eventArg){
		event=eventArg;
	}

	// @return EventQueue
	public EventQueue getEventQueue() {
		return eventQueue;
	}
	
	// @return typeArg
	public void setType(Class typeArg){
		type = typeArg;
	}
	
	//@return type
	public Class getType(){
		return type;
	}

}