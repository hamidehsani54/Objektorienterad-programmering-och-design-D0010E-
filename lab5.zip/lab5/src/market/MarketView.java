package market;
import java.util.Observable;
import simulator.*;

/**
 * @author Marcus and Hamid
 *
 *
 *         This Class print all the content in the console
 */
public class MarketView extends View {
	
	MarketState marketState;
	
	// String variables for the events
	String start = new String("Start         ");
	String ankomst = new String("Ankomst      ");
	String plock = new String("Plock        ");
	String betalning = new String("Betalning    ");
	String stanger = new String("Stänger        ");
	String stop = new String("Stop");
	String error = new String("Unknown       ");
	
	/**
	 * 	Constructor
	 * 
	 * @param marketState
	 * 
	 */
	public MarketView(MarketState marketState) {
		this.marketState = marketState;
		marketState.addObserver(this);
	}

	/**
	 * updates every event state in the colsole depending on the event type
	 * 
	 * @param arg0
	 * @param arg1
	 * 
	 */
	public void update(Observable arg0, Object arg1) {
		double time = marketState.getTime();
		int customerId = marketState.getEventCustomerId();
		boolean isOpen = marketState.getOpen();
		int freeCheckouts = marketState.freeCheckouts();
		double freeCheckoutTime = marketState.getFreeCheckoutTime();
		int currentCustAmount = marketState.getcurrentCustomers();
		int payed = marketState.getPayedCustomer();
		int missed	= marketState.getMissedCustomer();
		int queuedTot = marketState.getQueuedCustomer();
		double queueTime = marketState.getwaitedTime();
		int curQueue = marketState.customerAmountInQueue();

		String event;
		Class marketEventType = marketState.getType();
				
		if (marketEventType == OpenEvent.class) {
			event = start;
			
		}	
		else if (marketEventType == CloseEvent.class) {
			event = stanger;
		}
		else if (marketEventType == EntryEvent.class) {
			event = ankomst;
		}
		else if (marketEventType == CheckoutEvent.class) {
			event = plock;
		}
		else if (marketEventType == ExitEvent.class) {
			event = betalning;
		}
		else if (marketEventType == StopEvent.class){
		    event = stop; 
            System.out.println(time+"\tStop \n");
            return;
        }
		else {
			event = error;
		}
		
		String openString;
		if(isOpen) {
			openString = "Ö";
		}
		else {
			openString = "S";
			}
		
		
		System.out.printf("%.2f\t", time);
		System.out.print(event);
		if(event != start) {
		if(event==stanger) {
			System.out.print("\t---\tÖ");
				}
		else {
			System.out.print("\t"+customerId+"\t"+openString);
				}
		System.out.print("\t"+freeCheckouts+"\t");
		System.out.printf("%.2f\t", freeCheckoutTime);
		System.out.print(currentCustAmount+"\t"+payed+"\t"+missed+"\t"+queuedTot+"\t");
		System.out.printf("%.2f\t", queueTime);
		System.out.print(curQueue+"\t[");
		printCustomerQueue();}
		if(event == start) {
			System.out.print("\n");
			
	}
		}
	
	/**
	 * 	prints all the parameters for the specific run
	 
	 */
	public void printParameters() {
		
		System.out.println("PARAMETRAR");
		System.out.println("==========");
		System.out.println("Antal kassor, N..........: " + marketState.getCheckouts().length);
		System.out.println("Max som ryms, M..........: " + marketState.getmaxCustomers() );
		System.out.println("Ankomsthastighet, lambda.: " + marketState.getLamda());
		System.out.println("Plocktider, [P_min..PMax]: [" + marketState.getPickTimeMin()+".."+marketState.getPickTimeMax()+"]");
		System.out.println("Betaltider, [K_min..Kmax]: ["+ marketState.getPayTimeMin()+".."+marketState.getPayTimeMax()+"]");
		System.out.println("Frö, f...................: "+ marketState.getSeed());
		System.out.println(" ");
		System.out.println("FÖRLOPP");
		System.out.println("=======");
		System.out.println("Tid\tHändelse\tKund\t?\tled\tledT\tI\t$\t:-(\tköat\tköT\tköar\t[Kassakö..]");
	}
	

	/**
	 * 	prints the results for the specific run
	 
	 */
	public void printResults() {
		
		System.out.println("RESULTAT");
		System.out.println("========\n");
		System.out.print("1) Av " + (marketState.getcustomerIDCount() - 1) + " kunder handlade "
				+ marketState.getPayedCustomer() + " medan " + marketState.getMissedCustomer() + " missades.\n");
		System.out.print("\n2) Total tid " + marketState.getCheckouts().length + " kassor varit lediga: ");
		System.out.printf("%.2f", marketState.getFreeCheckoutTime());
		System.out.print(". \nGenomsnittlig ledig kassatid: ");
		System.out.printf("%.2f", (marketState.getFreeCheckoutTime() / marketState.getCheckouts().length));
		System.out.print(" te (dvs ");
		System.out.printf("%.2f", marketState.getFreeCheckoutTime() / marketState.getCheckouts().length
				/ marketState.getLastCustomerExit() * 100);
		System.out.print("% av tiden från öppning tills sista kunden betalat).\n");

		System.out.print("\n3) Total tid " + marketState.getQueuedCustomer() + " kunder tvingats köa: ");
		System.out.printf("%.2f", marketState.getwaitedTime());
		System.out.print(" te.\nGenomsnittlig kötid: ");
		System.out.printf("%.2f", marketState.getwaitedTime() / marketState.getQueuedCustomer());
		System.out.print(" te.\n");
	}
	

	/**
	 * 	prints the queue part in the console
	 */
	private void printCustomerQueue() {
		
		CustomerFactory[] marketQueue = marketState.getCustomerQueue();
		
		for (int i = 0; i < marketQueue.length; i++) {
			if (marketQueue[i] == null) {
				System.out.println("]");
				break;
			}
			System.out.print(marketQueue[i].getID());
			if (marketQueue[i+1] != null) {
				System.out.print(", ");
			}
		}
	}
}