package market;

import market.MarketState;
import simulator.Event;
/**
 * @author Marcus and Hamid
 *
 *
 *         This Class represents then a customer go thru the checkouts and the queue
 */
public class CheckoutEvent extends Event {
	double time;
	MarketState marketState;
	CustomerFactory costumer;
	/**
	 * 	Constructor
	 * 
	 * @param time
	 * @param marketState
	 * @param customer
	 */
	public CheckoutEvent(double time, MarketState marketState, CustomerFactory customer){
		super(time ,marketState);
		this.marketState=marketState;
		this.costumer=customer;
		this.time=time;
	}
	/**
	 * 	Runs the event and updates the statistic and data variables
	 */
	public void runEvent() {
		marketState.updateQueueNcheckout(time);
		if(marketState.checkoutIsEmpty()==true) {
			
			double payTime=time+marketState.getRandomPayRate();
			marketState.getEventQueue().sortEventSequence(new ExitEvent(payTime, marketState, costumer));
			marketState.emptyTheCheckout(); 
		}
		else {
			marketState.addCustomerToQueue(costumer);
			marketState.addQueuedCustomer();
			
		}
		/**
		 * 	Connects the events to specific objects
		 */
		marketState.setTime(time);
		marketState.setEventCustomer(costumer);
		marketState.setType(this.getClass());
		marketState.setChangeNotify();
	}
}