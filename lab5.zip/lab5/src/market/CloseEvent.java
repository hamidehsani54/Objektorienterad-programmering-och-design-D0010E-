package market;

import simulator.Event;
/**
 * @author Marcus Paulsson and Hamidullah Qurban
 *
 *
 *         This Class respresent the event when the market is being closed
 */
public class CloseEvent extends Event {
	MarketState marketState;
	double time;
	
	/**
	 * 	Constructor
	 * 
	 * @param time
	 * @param marketstate
	 */
	public CloseEvent(double time, MarketState marketstate){
		super(time, marketstate);
		this.marketState=marketstate;
		this.time=time;
	}
	/**
	 * 	Runs the event and updates the statistic and data variables
	 */
	public void runEvent() {
		marketState.updateQueueNcheckout(time);
		marketState.setEventCustomer(null);
		marketState.changeOpenState(false);
		marketState.setTime(time);
		marketState.setType(this.getClass());
		marketState.setChangeNotify();
	}
}