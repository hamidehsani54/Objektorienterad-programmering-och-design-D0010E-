package market;
import simulator.*;

/**
 * @author Marcus and Hamid
 *
 *
 *         This Class represent when a customer entry the market
 */
public class EntryEvent extends Event {

	private MarketState marketState;
	private double time;
	/**
	 * 	Constructor
	 * 
	 * @param time
	 * @param marketState
	 */
	public EntryEvent(double time, MarketState marketState) {
		super(time, marketState);
		this.marketState = marketState;
		this.time = time;
	}
	
	/**
	 * 	Runs the event and updates the statistic and data variables
	 */
	public void runEvent() {
		CustomerFactory customer = new CustomerFactory(marketState.getNextID(), marketState.getTime());
		if (marketState.getOpen() ) {
			marketState.updateQueueNcheckout(time);
		}

		if (marketState.getOpen() ) {
			if (marketState.getcurrentCustomers()<marketState.getmaxCustomers()) {
				
				marketState.addCurrentCustomers();
				double pickTime = time + marketState.getRandomPickRate();
				marketState.getEventQueue().sortEventSequence(new CheckoutEvent(pickTime, marketState, customer));
			
			}
			else {
				marketState.addMissedCustomer();
			}
			double nextArrivalTime = time + marketState.getRandomCostumerRate();
			marketState.getEventQueue().sortEventSequence(new EntryEvent(nextArrivalTime, marketState));
		}
		/**
		 * 	Connects the events to specific objects
		 */
		marketState.setTime(time);
		marketState.setType(getClass());
		marketState.setEventCustomer(customer);
		marketState.setChangeNotify();		
	}
}