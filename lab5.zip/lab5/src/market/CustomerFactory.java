package market;



 /**
 * @author Marcus Paulsson, Hamid Ehsani
 *
 *
 *This Class creates the customers
 */
public class CustomerFactory {
    private int ID;
    private double arrivalTime;
    private double queueArrivalTime;
    private double queueTime;
    private double exitTime;
   
    /**
	 * 	Constructor
	 * 
	 * @param IDArg
	 * @param arrivalArg
	 */
    public CustomerFactory(int IDArg, double arrivalArg){
        this.ID = IDArg-1;
        this.arrivalTime = arrivalArg;
    }

    /**
	 * @return ID
	 */
    public int getID(){
        return ID;
    }
    /**
	 * @return pickTime
	 */
    public double getPickTime(double pickTimeArg){
        return pickTimeArg - arrivalTime;
    }
    /**
	 * @return queueArrivalQueue
	 */
    public double getReachedQueueTime(double timeArg){
        queueArrivalTime = getPickTime(timeArg);
         arrivalTime=timeArg;
         return queueArrivalTime;
     }
    /**
	 * @return queueTime
	 */
    public double getQueueTime(double timeArg){
    	queueTime = timeArg-arrivalTime;
    	return queueTime;
    }
    /**
	 * @return checkoutTime
	 */
    public double getCheckoutTime(){
        return exitTime - queueTime;
    }
    /**
	 * @return exitTime
	 */
    public double getExitTime(double timeArg){
        exitTime = timeArg-arrivalTime;
        return exitTime;
    }
}