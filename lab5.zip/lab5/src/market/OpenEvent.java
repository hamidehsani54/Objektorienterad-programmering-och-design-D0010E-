package market;

import market.MarketState;
import simulator.Event;
/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 *	This Class represents then the market is opened
 */
public class OpenEvent extends Event {
	double time;
	MarketState marketState;
	
	/**
	 * Constructor, with parameters time and marketState
	 */
	public OpenEvent(MarketState marketState, double time){
		super(time,marketState);
		this.marketState=marketState;
		this.time=time;
	}
	
	 //method run those functions from marketsState. 
	
	public void runEvent() {
		marketState.updateQueueNcheckout(0);
		marketState.setEventCustomer(null);
		marketState.setType(this.getClass());
		marketState.changeOpenState(true);
		marketState.setChangeNotify();
	}
}