package market;
import simulator.Event;
/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 * This Class represents when the simulator is stopped
 */
public class StopEvent extends Event {
	MarketState marketState;
	double time;

	public StopEvent(double time, MarketState s) {
		super(time, s);
		this.marketState=s;
		this.time=time; 
	}

	//method run these function from marketSate
	public void runEvent(){
		marketState.setTime(this.time);
		marketState.updateQueueNcheckout(time);
		marketState.setFlag(false);
		marketState.setEventCustomer(null);
		marketState.setType(this.getClass());
		marketState.setChangeNotify();
	}
}