package market;

import simulator.*;

/**
 * @author Marcus and Hamid
 *
 *
 *         This Class represent when a customer exit the market
 */
public class ExitEvent extends Event {

	double time;
	MarketState marketState;
	CustomerFactory customer;
	
	/**
	 * 	Constructor
	 * 
	 * @param time
	 * @param marketState
	 * @param customer
	 */
	public ExitEvent(double time, MarketState marketState, CustomerFactory customer) {
		super(time, marketState);
		this.time=time;
		this.marketState = marketState;
		this.customer = customer;
	}
	
	/**
	 * 	Runs the event and updates the statistic and data variables
	 */
	public void runEvent() {
		
		marketState.updateQueueNcheckout(time);
		marketState.subCurrentCustomer();
		marketState.addPayedCustomer();
		CustomerFactory nextCustomer = marketState.subtractFromQueue();
		if (nextCustomer != null) {
			double payTime = time + marketState.getRandomPayRate();
			marketState.getEventQueue().sortEventSequence(new ExitEvent(payTime, marketState, nextCustomer));			
		}
		else {
			marketState.leftCheckout();
		}		
		
		/**
		 * 	Connects the events to specific objects
		 */
		marketState.setTime(time);
		marketState.setLastCustomerExit(time);
		marketState.setType(this.getClass());
		marketState.setEventCustomer(customer);
		marketState.setChangeNotify();
	
	}
}