package market;
import simulator.*;
import randomStreams.*;

/**
 * @author Marcus and Hamid
 *
 *
 *         This Class keeps track of the parameter, in store queue and the time statistics for the program
 */
public class MarketState extends State {
	
	// class variables
	private CustomerFactory customer;
	private ExponentialRandomStream randomCostumerRate; 
	private UniformRandomStream randomPayRate; 
	private UniformRandomStream randomPickRate; 
	
	// market variables
	private boolean open = false;
	double time;
	private double openTime;
	private int maxCustomers;
	private int checkouts;
	
	// Customer counters/statistics
	private int missed = 0;
	private int payed = 0;
	private int hadToQueue = 0;
	private double queueTime = 0; 
	private double freeCheckoutTime = 0;
	private double lastCustomerExit = 0;
	
	// queue counters and arrays
	private int[] checkoutsArray = new int[checkouts];
	private CustomerFactory[] customerQueue = new CustomerFactory[maxCustomers]; 
	private int currentCustomer = 0;
	private int IDCount = 0;
	
	// randomize parameters
	private double lambda; 
	private long seed;
	private double P_min;
	private double P_max;
	private double K_min;
	private double K_max;

	/**
	 * 	Constructor
	 * 
	 * @param time
	 * @param flag
	 * @param eventQueue
	 * @param maxCustomers
	 * @param checkouts
	 * @param timeopen
	 */
	public MarketState(double time, boolean flag, EventQueue eventQueue, int maxCustomers, int checkouts, double timeopen){
		super(time, flag, eventQueue);
		this.maxCustomers=maxCustomers;
		this.checkouts=checkouts;
		this.openTime=timeopen;
		checkoutsArray = new int[checkouts];
		customerQueue=new CustomerFactory[maxCustomers];	
	}
	
	/**
	 * 	creates a random stream for the different parameters
	 * 
	 * @param seedArg
	 * @param lamdaArg
	 * @param P_minArg
	 * @param P_maxArg
	 * @param K_minArg
	 * @param K_maxArg
	 */
	public void randomGenerator(int seedArg, double lambdaArg, double P_minArg, double P_maxArg, double K_minArg, double K_maxArg){
		lambda = lambdaArg;
		seed = seedArg;
		P_min = P_minArg;
		P_max = P_maxArg;
		K_min = K_minArg;
		K_max = K_maxArg;
		randomCostumerRate = new ExponentialRandomStream(lambdaArg, seedArg);
		randomPayRate = new UniformRandomStream(K_minArg, K_maxArg, seedArg);
		randomPickRate = new UniformRandomStream(P_minArg, P_maxArg, seedArg);
	}
	
	 /**
	 * @return A new randomPayRate
	 */
	public double getRandomPayRate(){
		return randomPayRate.next();
	}
	 /**
	 * @return A new randomPickRate
	*/
	public double getRandomPickRate(){
		return randomPickRate.next();
	}
	 /**
	* @return A new randomCustomerRate
	*/
	public double getRandomCostumerRate(){
		return randomCostumerRate.next();
	}
	 /**
		 * @return checkouts
		 */
	public int getNumCheckouts(){
		return checkouts;
	}
	 /**
		 * Creates a new checkout array depending on the new amount of checkouts
		 */
	public void changeVariables(int newCheckoutNum) {
		checkoutsArray = new int[newCheckoutNum];
	}
	
	 /**
		 * @return customerQueue
		 */
	public CustomerFactory[] getCustomerQueue() {
		return customerQueue;
	}

	 /**
	  * take and remove the first customer in the queue
		 * @return  firstCustomer
		 */
	public CustomerFactory subtractFromQueue() {
		CustomerFactory firstCustomer = customerQueue[0];
		for (int i = 1; i < customerQueue.length; i++) {
			customerQueue[i-1] = customerQueue[i];
		}
		customerQueue[customerQueue.length-1] = null;
		return firstCustomer;
	}

	 /**
		 * Adds a customer to the queue
		 */
	public void addCustomerToQueue(CustomerFactory newCustomer) {
		for (int i = 0; i < customerQueue.length; i++) {
			if (customerQueue[i] == null) {
				customerQueue[i] = newCustomer;
				break;
			}
		}
	}
	
	 /**
		 * @return The amount of customers in the queue
		 */
	public int customerAmountInQueue() {
		int queueCount = 0;
		for (int i = 0; i < customerQueue.length; i++) {
			if (customerQueue[i] == null) {
				break;
			}
			queueCount++;
		}
		return queueCount;
	}
	
	 /**
		 * sets the time to a specific object
		 * @param timeArg
		 */
	public void setTime(double timeArg){
		this.time = timeArg;
		super.setTime(timeArg);
	}
	
	 /**
		 * @return IDCount
		 */
	public int getNextID() {
		IDCount++;
		return IDCount;
	}
	
	 /**
		 * @return open
		 */
	public boolean getOpen(){
		return open;
	}
	
	 /**
		 * change the current state to the argument
		 * 
		 * @param openArg
		 */
	public void changeOpenState(boolean openArg){
		open=openArg;
	}
	
	/**
	 * @return missedCustomers
	 */
	public int getMissedCustomer(){
		return missed;
	}
	
	/**
	 * Adds to missed customers
	 */
	public void addMissedCustomer(){
		missed++;
	}
	
	/**
	 * @return Payes customers
	 */
	public int getPayedCustomer(){
		return payed;
	}
	
	/**
	 * Adds to payed customers
	 */
	public void addPayedCustomer(){
		payed++;
	}
	
	/**
	 * @return queuedCustomers
	 */
	public int getQueuedCustomer() {
		return hadToQueue;
	}

	/**
	 * Adds to queued customers
	 */
	public void addQueuedCustomer() {
		hadToQueue++;
	}
	
	/**
	 * @return current Customers
	 */
	public int getcurrentCustomers(){
		return currentCustomer;	
	}
	
	/**
	 * Adds to current customers
	 */
	public void addCurrentCustomers(){
		currentCustomer++;
		
	}

	/**
	 * remove one from current customers
	 */
	public void subCurrentCustomer(){
		currentCustomer--;
	}
	
	/**
	 * help methods to setChanged() and notifyObservers().
	 */
	public void setChangeNotify(){
		setChanged();
		notifyObservers();
	}
	
	/**
	 *  Updates the current timestatistics that are printed in the simulation
	 */
	public void updateQueueNcheckout(double timeArg) {
		queueTime = queueTime + (timeArg-time)*customerAmountInQueue();
		int freeCheckouts = 0;
		for (int i = 0; i < checkoutsArray.length; i++) {
			freeCheckouts += 1 - checkoutsArray[i];
		}
		freeCheckoutTime = freeCheckoutTime + (timeArg-time)*freeCheckouts;
	}
	
	/**
	 * Are called whenever a customer leaves the queue.
	 */
	public void leftCheckout() {
		for (int i = 0; i < checkoutsArray.length; i++) {
			if (checkoutsArray[i] == 1) {
				checkoutsArray[i] = 0;
				return;
			}
		}
	}
	
	/**
	 * checks if a checkout is empty 
	 * 
	 *  @return true if there is an empty checkout, false if there is not
	 */
	public boolean checkoutIsEmpty(){
		for (int i = 0; i < checkoutsArray.length; i++) {
			if (checkoutsArray[i] == 0) {
				return true;	
			}
		}
		return false;
	}
	
	/**
	 * removes a customer from a checkout
	 */
	public void emptyTheCheckout() {
		for (int i = 0; i < checkoutsArray.length; i++) {
			if (checkoutsArray[i] == 0) {
				checkoutsArray[i] = 1;
				break;
			}
		}
	}
	
	/**
	 * count how many free checkouts there is
	 * 
	 *  @return the amount of free checkouts
	 */
	public int freeCheckouts() {
		int regCount = 0;
		for (int i = 0; i < checkoutsArray.length; i++) {
			if (checkoutsArray[i] == 0) {
				regCount++;
			}
		}
		return regCount;
	}
	
	/**
	 * connects a customer to a specific event
	 */
	public void setEventCustomer(CustomerFactory customerArg) {
		customer = customerArg;
	}
	
	/**
	 * get the customer id for the event
	 * 
	 * @return the ID of the customer
	 */
	public int getEventCustomerId() {
		if (customer == null) {
			return 0;
		}
		else {
			return customer.getID();
		}
	}
		
	/**
	 * @return checkout array
	 */
	public int[] getCheckouts(){
		return checkoutsArray;
	}
	
	/**
	 * @return maxCustomers
	 */
	public int getmaxCustomers(){
		return maxCustomers;
	}
	
	/**
	 * @return queueTime
	 */
	public double getwaitedTime(){
		return queueTime;
	}
	
	/**
	 * @return the counter for the IDs
	 */
	public int getcustomerIDCount(){
		return IDCount;
	}
	
	/**
	 * @return the time the market is open
	 */
	public double getTimeOpen(){
		return openTime;
	}
	
	/**
	 * @return amount of free checkouts
	 */
	public double getFreeCheckoutTime(){
		return freeCheckoutTime;
	}

	/**
	 * @return lambda
	 */
	public double getLamda() {
		return lambda;
	}
	
	/**
	 * @return P_max
	 */
	public double getPickTimeMax() {
		return P_max;	
	}
	
	/**
	 * @return P_min
	 */
	public double getPickTimeMin() {
		return P_min;
	}
	
	/**
	 * @return K_max
	 */
	public double getPayTimeMax() {
		return K_max;
	}
	
	/**
	 * @return K_min
	 */
	public double getPayTimeMin() {
		return K_min;
	}
	
	/**
	 * @return seed
	 */
	public long getSeed() {
		return seed;
	}
	
	/**
	 * @return the last customer that exited the market
	 */
	public double getLastCustomerExit() {
		return lastCustomerExit;
	}
	
	/**
	 * Sets a time when the customer exited the market
	 */
	public void setLastCustomerExit(double time) {
		lastCustomerExit = time;
	}
}