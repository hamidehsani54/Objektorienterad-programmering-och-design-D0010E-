package randomStreams;

import java.util.Random;
/**
 * @author hamidullah.qurban, Marcus Paulsson
 *	This Class contains the randomize function
 */


public class ExponentialRandomStream {
	
	private Random rand;
	private double lambda;
	/*
	 *constructor of the class variables rand and lambda. 
	 */
	public ExponentialRandomStream(double lambda, long seed) {
	  	rand = new Random(seed);
	  	this.lambda = lambda;
	}
	/*
	 * constructor
	 */
	public ExponentialRandomStream(double lambda) {
		rand = new Random();
	    this.lambda = lambda;
	}
	  
	public double next() {
	  	return -Math.log(rand.nextDouble())/lambda;
	}
}