package randomStreams;

import java.util.Random;

/**
 * @author hamidullah.qurban, Marcus Paulsson
 *
 *	This Class contains the randomize methods
 */
public class UniformRandomStream {

	private Random rand;
	private double lower, width;
	
	/*
	 * constructor with lower and width
	 */
	
	public UniformRandomStream(double lower, double upper, long seed) {
		rand = new Random(seed);
		this.lower = lower;
		this.width = upper-lower;
	}
	
	/*
	 * constructor, lower and width
	 */
	public UniformRandomStream(double lower, double upper) {
		rand = new Random();
	    this.lower = lower;
	    this.width = upper-lower;
	}
	/*
	 * return
	 */
	public double next() {
	    return lower+rand.nextDouble()*width;
	}
}