import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class GraphIO   {

    static public void readFile(Graph g, String filename) throws IOException {
        File fil = new File(filename);
        try {
            Scanner scanner = new Scanner(fil);
            int nodes = scanner.nextInt();

            int counter = 0;
            while(true) {
                if(counter == nodes) {
                    break;
                }
                g.addNode(scanner.nextInt(),scanner.nextInt(), scanner.nextInt());
                counter +=1;
            }
            while(scanner.hasNext()) {
                g.addEdge(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
            }
            scanner.close();
        }catch(FileNotFoundException e) {
            throw new IOException();
            }
        }
    

}