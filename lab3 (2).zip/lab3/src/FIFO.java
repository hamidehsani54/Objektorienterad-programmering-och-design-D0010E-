
import java.util.ArrayList;
import java.util.NoSuchElementException;

public class FIFO  implements Queue{
		private ArrayList <Object> intArray= new ArrayList<Object>();
		private int max=0;
		//private int size = 0;
		
		public String toString() {
			String a = "";
			for(int i=0; i<intArray.size(); i++) {
				a= a+ "(" + String.valueOf(intArray.get(i)) + ") "
;
			}
			return "Queue: " + a;
		}			

		public Object first() throws NoSuchElementException {
			if(this.intArray.size() ==0) {
				//System.out.println("hejj");
				//System.out.println("first == 0: " + size);
				throw new NoSuchElementException();
			}
			else{
				//System.out.println(this.intArray.size());
				//System.out.println("first >0: " + size);
				return this.intArray.get(0);
				
				
		
			}
			
		}

		public boolean isEmpty() {
			if(intArray.size()==0) {
				return true;
			}
			else {
				return false;
			
			}
		}

		
		public int maxSize() {
			// TODO Auto-generated method stub
			return max;
		}

		
		public void removeFirst() throws NoSuchElementException {
			if(this.intArray.size()!=0) {
				this.intArray.remove(0);	
				//size--;
			}
			else if(this.intArray.size()==0) {
				throw new NoSuchElementException();
			}
			//ystem.out.println("remove first:" + size + " " + this.hashCode());
			
			
		}
		public void add(Object item) {			
			this.intArray.add(item);
			max++;
			//size++;
			//System.out.println("add: " + size + " " + this.hashCode());
			//System.out.println("add list :" + this.intArray.size());
		}

		
		public int size() {
			// TODO Auto-generated method stub
			return this.intArray.size();
		}
		public boolean equals(Object f) throws ClassCastException{
			try {
			if( f instanceof FIFO) {
				
				if(this.intArray.size() == (((FIFO)f).intArray.size())) {
				for(int i=0; i<this.intArray.size(); i++){
					
					if (intArray.get(i)==null) {
						if(((FIFO)f).intArray.get(i)==null) {
							
							continue;
						}
						else{
							return false;
						}
						
					
						
					}
					if(this.intArray.get(i).equals(((FIFO)f).intArray.get(i))){
						continue;
					}
					else{
						return false;
					}
					
					
					
					}
				return true;
			}
			}

		}
			catch (ClassCastException e) {
				System.out.println(e);
				
			}
			return false;
		
		
	}}
		
