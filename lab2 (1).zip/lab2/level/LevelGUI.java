package lab2.level;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Observable;
import java.util.Observer;
import lab2.level.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class LevelGUI implements Observer {

	private Level lv;
	private Display d;

	public LevelGUI(Level level, String name) {
	
		this.lv = level;

		level.addObserver(this);

		JFrame frame = new JFrame(name);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// TODO: You should change 200 to a value
		// depending on the size of the level
		d = new Display(lv, lv.getMaxXSize(), lv.getMaxYSize());
		frame.getContentPane().add(d);
		frame.pack();
		frame.setLocation(300, 100);
		frame.setVisible(true);
	}

	public void update(Observable arg0, Object arg1) {
		d.repaint();

	}

	private class Display extends JPanel {

		public Display(Level fp, int x, int y) {
			

			addKeyListener(new Listener());

			setBackground(Color.WHITE);
			setPreferredSize(new Dimension(x + 20, y + 20));
			setFocusable(true);
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);

			for (int i = 0; i < lv.getRoomList().size(); i++) {
				// Rita alla rum med hj�lp av deras storlek och f�rg
				g.setColor(lv.getRoomList().get(i).color);
				g.fillRect(lv.getRoomList().get(i).xCoordinate, lv.getRoomList().get(i).yCoordinate, lv.getRoomList().get(i).xD,
						lv.getRoomList().get(i).yD);

				// Rita korridorerna medllan alla rum med hj�lp av cooridorLine metoden
				for (int j = 0; j < lv.getRoomList().size(); j++) {
					cooridorLine(lv.getRoomList().get(i), lv.getRoomList().get(j), g);
				}

				// Rita av spelaren
				if (lv.getRoomList().get(i).playerInRoom == true) {
					g.setColor(Color.WHITE);
					g.fillRect(lv.getRoomList().get(i).xCoordinate + 7, lv.getRoomList().get(i).yCoordinate + 7,
							lv.getRoomList().get(i).xD - 15, lv.getRoomList().get(i).yD - 15);
				}
			}

		}

		private void cooridorLine(Room r1, Room r2, Graphics g) {

			if (r1.northSide == r2) {

				g.drawLine(r1.xCoordinate + r1.xD / 2, r1.yCoordinate, r2.xCoordinate + r2.xD / 2,
						r2.yCoordinate + r2.yD);
			} else if (r1.eastSide == r2) {

				g.drawLine(r1.xCoordinate + r1.xD, r1.yCoordinate + r1.yD / 2, r2.xCoordinate,
						r2.yCoordinate + r2.yD / 2);
			} else if (r1.southSide == r2) {

				g.drawLine(r1.xCoordinate + r1.xD / 2, r1.yCoordinate + r1.yD, r2.xCoordinate + r2.xD / 2,
						r2.yCoordinate);
			} else if (r1.westSide == r2) {

				g.drawLine(r1.xCoordinate, r1.yCoordinate + r1.yD / 2, r2.xCoordinate + r2.xD,
						r2.yCoordinate + r2.yD / 2);
			}
		}

		private class Listener implements KeyListener {

			public void keyPressed(KeyEvent arg0) {
				char keyInput = arg0.getKeyChar();

				switch (keyInput) {

				case 'W':
					lv.movePlayer(1);
					break;
				case 'w':
					lv.movePlayer(1);
					break;
				case 'A':
					lv.movePlayer(4);
					break;
				case 'a':
					lv.movePlayer(4);
					break;
				case 'S':
					lv.movePlayer(3);
					break;
				case 's':
					lv.movePlayer(3);
					break;
				case 'D':
					lv.movePlayer(2);
					break;
				case 'd':
					lv.movePlayer(2);
					break;
				}

			}

			public void keyReleased(KeyEvent arg0) {
			}

			public void keyTyped(KeyEvent event) {

			}
		}

	}

}