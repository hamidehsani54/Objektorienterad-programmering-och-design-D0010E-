package lab2.level;

import java.awt.Color;

public class Room {

	boolean playerInRoom = false;

	int xD, yD, xCoordinate, yCoordinate;

	public Color color;

	Room northSide = null;
	Room eastSide = null;
	Room southSide = null;
	Room westSide = null;

	public Room(int xd, int yd, Color color) {

		this.xD = xd;
		this.yD = yd;
		this.color = color;

	}

	public void connectNorthTo(Room r) {
		this.northSide = r;

	}

	public void connectEastTo(Room r) {
		this.eastSide = r;

	}

	public void connectSouthTo(Room r) {
		this.southSide = r;

	}

	public void connectWestTo(Room r) {
		this.westSide = r;
	}
}
