package lab2.level;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;

public class Level extends Observable {

	private boolean noRoom = true;
	private ArrayList<Room> roomList = new ArrayList<Room>();
	private int maxXSize = 0;
	private int maxYSize = 0;

	public Level() {

	}

	/*
	 * Metoden movePlayer har uppgift att flytta spelaren mellan olika rum och
	 * inneh�ller tv� loopar d�r (i) �r kollar vilket rum spelaren befinner sig och
	 * (j) kollar vilket koridor har rummet.
	 */
	void movePlayer(int n) {

		for (int i = 0; i < roomList.size(); i++) {

			if (roomList.get(i).playerInRoom == true) {

				for (int j = 0; j < roomList.size(); j++) {
					if (roomList.get(i).northSide == roomList.get(j) && n == 1) {
						roomList.get(i).playerInRoom = false;
						roomList.get(j).playerInRoom = true;
						setChanged();
						notifyObservers();
					}
					if (roomList.get(i).eastSide == roomList.get(j) && n == 2) {

						roomList.get(i).playerInRoom = false;
						roomList.get(j).playerInRoom = true;
						setChanged();
						notifyObservers();
					}
					if (roomList.get(i).southSide == roomList.get(j) && n == 3) {

						roomList.get(i).playerInRoom = false;
						roomList.get(j).playerInRoom = true;
						setChanged();
						notifyObservers();
					}
					if (roomList.get(i).westSide == roomList.get(j) && n == 4) {

						roomList.get(i).playerInRoom = false;
						roomList.get(j).playerInRoom = true;
						setChanged();
						notifyObservers();
					}
				}
			}
		}

	}

	/*
	 * Metoden checkOverlapping har uppgift att j�mf�ra tv� rum med varandra med
	 * hj�lp av rummernas x och y koordinat och deras storlek och kollar om de
	 * �verl�ppar varandra eller inte
	 */
	private boolean checkOverlapping(Room r1, Room r2) {
		int oldRoomXCoord = r1.xCoordinate;
		int newRoomXCoord = r2.xCoordinate;
		int oldRoomYCoord = r1.yCoordinate;
		int newRoomYCoord = r2.yCoordinate;
		int oldRoomXCoordAndDem = r1.xCoordinate + r1.xD;
		int newRoomXCoordAndDem = r2.xCoordinate + r2.xD;
		int oldRoomYCoordAndDem = r1.yCoordinate + r1.yD;
		int newRoomYCoordAndDem = r2.yCoordinate + r2.yD;

		if (newRoomXCoord >= oldRoomXCoord && newRoomXCoord <= oldRoomXCoordAndDem && newRoomYCoord >= oldRoomYCoord
				&& newRoomYCoord <= oldRoomYCoordAndDem) {
			return false;
		}
		if (newRoomXCoord >= oldRoomXCoord && newRoomXCoord <= oldRoomXCoordAndDem
				&& newRoomYCoordAndDem >= oldRoomYCoord && newRoomYCoordAndDem <= oldRoomYCoordAndDem) {
			return false;
		}
		if (newRoomXCoordAndDem >= oldRoomXCoord && newRoomXCoordAndDem <= oldRoomXCoordAndDem
				&& newRoomYCoord >= oldRoomYCoord && newRoomYCoord <= oldRoomYCoordAndDem) {
			return false;
		}
		if (newRoomXCoordAndDem >= oldRoomXCoord && newRoomXCoordAndDem <= oldRoomXCoordAndDem
				&& newRoomYCoordAndDem >= oldRoomYCoord && newRoomYCoordAndDem <= oldRoomYCoordAndDem) {
			return false;
		}
		if (newRoomXCoord <= oldRoomXCoord && newRoomXCoordAndDem >= oldRoomXCoordAndDem
				&& newRoomYCoord >= oldRoomYCoord && newRoomYCoordAndDem <= oldRoomYCoordAndDem) {
			return false;
		}

		return true;

	}

	/*
	 * Metoden place har en uppgift att placera de rum i Arraylistan om rummet som
	 * skapat inte �verl�ppar med annat rum som finns i listan redan med hj�lp av
	 * metoden checkOverlapping.
	 */
	public boolean place(Room r, int x, int y) {
		r.xCoordinate = x;
		r.yCoordinate = y;

		for (int i = 0; i < roomList.size(); i++) {
			if (checkOverlapping(r, roomList.get(i)) == false) {
				System.out.println("ERROR: Overlapping rooms");
				return false;
			}
		}
		checkXSize(r);
		checkYSize(r);
		roomList.add(r);
		

		return true;
	}

	// Metoden firstLocation har uppgift att placera spelaren i rummet.
	public void firstLocation(Room r) {
		r.playerInRoom = true;
		noRoom = false;

	}

	public boolean isNoRoom() {
		return noRoom;
	}

	public ArrayList<Room> getRoomList() {
		return roomList;
	}

	
	
	public int checkXSize(Room r) {
		if (r.xCoordinate + r.xD > maxXSize) {
			maxXSize = r.xCoordinate + r.xD;
		}

		return maxXSize;
	}
	public int checkYSize(Room r) {
		if (r.yCoordinate + r.yD > maxYSize) {
			maxYSize = r.yCoordinate + r.yD;
		}
		return maxYSize;
	}
	public int getMaxXSize() {
		return maxXSize;
	}


	public int getMaxYSize() {
		return maxYSize;
	}
	
	

	
	
}