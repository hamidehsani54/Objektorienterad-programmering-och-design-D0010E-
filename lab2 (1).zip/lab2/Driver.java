package lab2;

import java.awt.Color;

import lab2.level.Level;
import lab2.level.LevelGUI;
import lab2.level.Room;

/*
 * Klass Driver har endast en metod Run d�r skapas alla rum med deras f�rg, storlek 
 * och h�r skapas �ven level och levelGUI som har ansvar f�r utseende.
 */
public class Driver {

	public void run() {

		Level level1 = new Level();
		// H�r skapas alla rum med storlek och f�rg
		Room r1 = new Room(50, 50, Color.blue);
		Room r2 = new Room(50, 50, Color.red);
		Room r3 = new Room(50, 50, Color.green);
		Room r4 = new Room(50, 50, Color.black);
		Room r5 = new Room(50, 50, Color.orange);
		Room r6 = new Room(50, 50, Color.MAGENTA);
		//Room r7 = new Room(50, 50, Color.cyan);

		level1.firstLocation(r3); // Best�mma vilket rum man ska b�rja p�

		// H�r skapas alla linjer mellan alla rum d�r man f� best�mma vilka rum ska ha
		// kontakt med varandra
		r1.connectWestTo(r2);
		r2.connectNorthTo(r4);
		r4.connectEastTo(r3);
		r3.connectEastTo(r5);
		r5.connectSouthTo(r6);
		r6.connectWestTo(r1);
		r1.connectNorthTo(r3);
		r2.connectEastTo(r6);
		r5.connectWestTo(r4);


		level1.place(r1, 285, 500);
		level1.place(r2, 125, 350);
		level1.place(r3, 285, 50);
		level1.place(r4, 280, 60);
		level1.place(r5, 440, 190);
		level1.place(r6, 440, 350);
		//level1.place(r7, 420, 200);
		
		LevelGUI levelGUI = new LevelGUI(level1, "level1");

	}
	


}